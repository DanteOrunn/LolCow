package interfaces;

public interface Comparador {

    public boolean igualQue(Object op2);

    public boolean menorQue(Object op2);

    public boolean menorIgualQue(Object op2);

    public boolean mayorQue(Object op2);

    public boolean mayorIgualQue(Object op2);
}
